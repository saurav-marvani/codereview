(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_d9c40afb._.js",
  "static/chunks/node_modules_next_38d3a78f._.js",
  "static/chunks/node_modules_@auth_core_2b0ef625._.js",
  "static/chunks/node_modules_zod_v4_f6208312._.js",
  "static/chunks/node_modules_jose_dist_webapi_7006a6b8._.js",
  "static/chunks/node_modules_axios_lib_99e19c7d._.js",
  "static/chunks/node_modules_18c71229._.js"
],
    source: "dynamic"
});
