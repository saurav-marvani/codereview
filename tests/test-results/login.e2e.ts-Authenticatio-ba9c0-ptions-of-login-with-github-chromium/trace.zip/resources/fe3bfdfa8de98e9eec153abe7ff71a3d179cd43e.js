(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__acc12b9a._.css",
  "static/chunks/node_modules_e1c90651._.js",
  "static/chunks/src_core_e787ddc1._.js"
],
    source: "dynamic"
});
